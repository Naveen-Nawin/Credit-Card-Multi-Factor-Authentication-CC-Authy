package com.project.creditPay.dataLayer.models

data class LoadersResults(
    var message: String? = null,
    var condition: Boolean? = null,
)